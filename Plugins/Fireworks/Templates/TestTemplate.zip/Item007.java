package net.tuyapin;
 
import java.util.List;
import java.util.Random;
 
import net.minecraft.block.Block;
import net.minecraft.block.BlockFalling;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Blocks;
import net.minecraft.util.IProgressUpdate;
import net.minecraft.util.MathHelper;
import net.minecraft.world.ChunkPosition;
import net.minecraft.world.SpawnerAnimals;
import net.minecraft.world.World;
import net.minecraft.world.WorldType;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.MapGenBase;
import net.minecraft.world.gen.MapGenCaves;
import net.minecraft.world.gen.MapGenRavine;
import net.minecraft.world.gen.NoiseGenerator;
import net.minecraft.world.gen.NoiseGeneratorOctaves;
import net.minecraft.world.gen.NoiseGeneratorPerlin;
import net.minecraft.world.gen.feature.WorldGenDungeons;
import net.minecraft.world.gen.feature.WorldGenLakes;
import net.minecraft.world.gen.structure.MapGenMineshaft;
import net.minecraft.world.gen.structure.MapGenScatteredFeature;
import net.minecraft.world.gen.structure.MapGenStronghold;
import net.minecraft.world.gen.structure.MapGenVillage;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.terraingen.ChunkProviderEvent;
import net.minecraftforge.event.terraingen.InitMapGenEvent.EventType;
import net.minecraftforge.event.terraingen.PopulateChunkEvent;
import net.minecraftforge.event.terraingen.TerrainGen;
import cpw.mods.fml.common.eventhandler.Event.Result;
 
public class ChunkProviderFloatingIsland implements IChunkProvider
{
    private Random rand;
 
    /* Noise Generators */
    private NoiseGeneratorOctaves noiseGen1;
    private NoiseGeneratorOctaves noiseGen2;
    private NoiseGeneratorOctaves noiseGen3;
    private NoiseGeneratorPerlin noiseGen4;
    public NoiseGeneratorOctaves noiseGen5;
    public NoiseGeneratorOctaves noiseGen6;
    public NoiseGeneratorOctaves mobSpawnerNoise;
 
    private World worldObj;
    private final boolean mapFeaturesEnabled;
    private WorldType worldType;
 
    private final double[] field_147434_q;
    private final float[] parabolicField;
 
    private double[] stoneNoise = new double[256];
 
    private MapGenBase caveGenerator = new MapGenCaves();
    /* REPLACED */
    private MapGenStronghold strongholdGenerator = new MapGenStronghold();
    private MapGenVillage villageGenerator = new MapGenVillage();
    private MapGenMineshaft mineshaftGenerator = new MapGenMineshaft();
    private MapGenScatteredFeature scatteredFeatureGenerator = new MapGenScatteredFeature();
    private MapGenBase ravineGenerator = new MapGenRavine();
    private BiomeGenBase[] biomesForGeneration;
 
    double[] field_147427_d;
    double[] field_147428_e;
    double[] field_147425_f;
    double[] field_147426_g;
    int[][] field_73219_j = new int[32][32];
 
    /* Floating Island */
    private int spawnHigh;
    private int islandHigh;
    private int islandEve;
    private int spawnFlag;
    private int dis;
    private int mainMax;
    private int[] roundNess;
    private boolean skip;
    private boolean round;
    private boolean spawnPoint;
 
    {
        caveGenerator = TerrainGen.getModdedMapGen(caveGenerator, EventType.CAVE);
        strongholdGenerator = (MapGenStronghold)TerrainGen.getModdedMapGen(strongholdGenerator, EventType.STRONGHOLD);
        villageGenerator = (MapGenVillage)TerrainGen.getModdedMapGen(villageGenerator, EventType.VILLAGE);
        mineshaftGenerator = (MapGenMineshaft)TerrainGen.getModdedMapGen(mineshaftGenerator, EventType.MINESHAFT);
        scatteredFeatureGenerator = (MapGenScatteredFeature)TerrainGen.getModdedMapGen(scatteredFeatureGenerator, EventType.SCATTERED_FEATURE);
        ravineGenerator = TerrainGen.getModdedMapGen(ravineGenerator, EventType.RAVINE);
    }
 
    public ChunkProviderFloatingIsland(World par1World, long par2LongSeed, boolean par3BooleanMapFeaturesEnabled)
    {
        this.worldObj = par1World;
        this.mapFeaturesEnabled = par3BooleanMapFeaturesEnabled;
        this.worldType = par1World.getWorldInfo().getTerrainType();
        this.rand = new Random(par2LongSeed);
        this.noiseGen1 = new NoiseGeneratorOctaves(this.rand, 16);
        this.noiseGen2 = new NoiseGeneratorOctaves(this.rand, 16);
        this.noiseGen3 = new NoiseGeneratorOctaves(this.rand, 8);
        this.noiseGen4 = new NoiseGeneratorPerlin(this.rand, 4);
        this.noiseGen5 = new NoiseGeneratorOctaves(this.rand, 10);
        this.noiseGen6 = new NoiseGeneratorOctaves(this.rand, 16);
        this.mobSpawnerNoise = new NoiseGeneratorOctaves(this.rand, 8);
        this.field_147434_q = new double[825];
        this.parabolicField = new float[25];
        for(int i = -2; i <= 2; i++)
        {
            for(int j = -2; j <= 2; j++)
            {
                float f = 10.0F / MathHelper.sqrt_float(i * i + j * j + 0.2F);
                this.parabolicField[(i + 2 + (j + 2) * 5)] = f;
            }
        }
        NoiseGenerator[] noiseGens = { this.noiseGen1, this.noiseGen2, this.noiseGen3, this.noiseGen4, this.noiseGen5, this.noiseGen6, this.mobSpawnerNoise };
        noiseGens = TerrainGen.getModdedNoiseGenerators(par1World, this.rand, noiseGens);
 
        this.noiseGen1 = (NoiseGeneratorOctaves)noiseGens[0];
        this.noiseGen2 = (NoiseGeneratorOctaves)noiseGens[1];
        this.noiseGen3 = (NoiseGeneratorOctaves)noiseGens[2];
        this.noiseGen4 = (NoiseGeneratorPerlin)noiseGens[3];
        this.noiseGen5 = (NoiseGeneratorOctaves)noiseGens[4];
        this.noiseGen6 = (NoiseGeneratorOctaves)noiseGens[5];
        this.mobSpawnerNoise = (NoiseGeneratorOctaves)noiseGens[6];
    }
 
    public int getSqrt(int par1, int par2, int par3, int par4)
    {
        return (int)Math.sqrt((par3 - par1) * (par3 - par1) + (par4 - par2) * (par4 - par2));
    }
 
    public void setupGenerator(int par1, int par2)
    {
        this.spawnHigh = 0;
        this.islandHigh = this.rand.nextInt(210);
        this.islandEve = this.rand.nextInt(30);
        this.round = false;
        this.skip = false;
        this.mainMax = this.rand.nextInt(10);
        this.roundNess = new int[256];
        for(int i = 0; i < 256; i++)
        {
            this.roundNess[i] = this.mainMax + this.rand.nextInt(2) - this.rand.nextInt(4);
        }
        if(this.rand.nextInt(70) == 0)
        {
            this.skip = true;
        }
    }
 
    public void setupIslandLayer(int par1, int par2)
    {
        this.dis = this.getSqrt(8, 8, par1, par2);
        if(this.dis < 64)
        {
            this.round = true;
        }
        this.spawnFlag = -1;
        if(this.rand.nextInt(700) == 0)
        {
            this.skip = true;
        }
    }
 
    public void generateTerrain(int par1, int par2, Block[] par3ArrayOfBlock)
    {
        byte b0 = 63;
        this.biomesForGeneration = this.worldObj.getWorldChunkManager().getBiomesForGeneration(this.biomesForGeneration, par1  * 4 - 2, par2 * 4 - 2, 10, 10);
        this.initializeNoiseField(par1 * 4, 0, par2 * 4);
 
        for(int i = 0; i < 4; i++)
        {
            int i0 = i * 5;
            int i1 = (i + 1) * 5;
 
            for(int j = 0; j < 4; j++)
            {
                int i2 = (i0 + j) * 33;
                int i3 = (i0 + j + 1) * 33;
                int i4 = (i1 + j) * 33;
                int i5 = (i1 + j + 1) * 33;
 
                for(int k = 0; k < 32; k++)
                {
                    double d0 = 0.125D;
                    double d1 = this.field_147434_q[i2 + k];
                    double d2 = this.field_147434_q[i3 + k];
                    double d3 = this.field_147434_q[i4 + k];
                    double d4 = this.field_147434_q[i5 + k];
                    double d5 = (this.field_147434_q[i2 + k + 1] - d1) * d0;
                    double d6 = (this.field_147434_q[i3 + k + 1] - d2) * d0;
                    double d7 = (this.field_147434_q[i4 + k + 1] - d3) * d0;
                    double d8 = (this.field_147434_q[i5 + k + 1] - d4) * d0;
 
                    for(int l = 0; l < 8; l++)
                    {
                        double d9 = 0.25D;
                        double d10 = d1;
                        double d11 = d2;
                        double d12 = (d3 - d1) * d9;
                        double d13 = (d4 - d2) * d9;
 
                        for(int n = 0; n < 4; n++)
                        {
                            int i6 = n + i * 4 << 12 | 0 + j * 4 << 8 | k * 8 + l;
                            short s1 = 256;
                            i6 -= s1;
                            double d14 = 0.25D;
                            double d16 = (d11 - d10) * d14;
                            double d15 = d10 - d16;
 
                            for(int m = 0; m < 4; m++)
                            {
                                if((d15 += d16) > 0.0D)
                                {
                                    par3ArrayOfBlock[i6 += s1] = Blocks.stone;
                                }
                                else if(k * 8 + l < b0)
                                {
                                    par3ArrayOfBlock[i6 += s1] = Blocks.water;
                                }
                                else
                                {
                                    par3ArrayOfBlock[i6 += s1] = null;
                                }
                            }
 
                            d10 += d12;
                            d11 += d13;
                        }
 
                        d1 += d5;
                        d2 += d6;
                        d3 += d7;
                        d4 += d8;
                    }
                }
            }
        }
    }
 
    public void replaceBlocksForBiome(int par1, int par2, Block[] par3ArrayOfBlock, byte[] par4ArrayOfByte, BiomeGenBase[] par5ArrayOfBiomeGenBase)
    {
        //Deprecated
        //ChunkProviderEvent.ReplaceBiomeBlocks event = new ChunkProviderEvent.ReplaceBiomeBlocks(this, par1, par2, par3ArrayOfBlock, par5ArrayOfBiomeGenBase);
        ChunkProviderEvent.ReplaceBiomeBlocks event = new ChunkProviderEvent.ReplaceBiomeBlocks(this, par1, par2, par3ArrayOfBlock, par4ArrayOfByte, par5ArrayOfBiomeGenBase, this.worldObj);
        MinecraftForge.EVENT_BUS.post(event);
 
        if(event.getResult() == Result.DENY)
        {
            return;
        }
 
        double d0 = 0.03125D;
        this.stoneNoise = this.noiseGen4.func_151599_a(this.stoneNoise, (double)par1 * 16, (double)par2 * 16, 16, 16, d0 * 2.0D, d0 * 2.0D, 1.0D);
        this.setupGenerator(par1, par2);
        for(int i = 0; i < 16; i++)
        {
            for(int j = 0; j < 16; j++)
            {
                BiomeGenBase biomeGenBase = par5ArrayOfBiomeGenBase[(j + i * 16)];
 
                byte b0 = 63;
                byte b1 = 0;
                Block topBlock = Blocks.grass;
                Block fillerBlock = Blocks.dirt;
                int i1 = -1;
                int i2 = (int)(this.stoneNoise[(j + i * 16)] / 3.0D + 3.0D + this.rand.nextDouble() * 0.25D);
                int i3 = par1 * 16 + i & 0xF;
                int i4 = par2 * 16 + j & 0xF;
                int i5 = par3ArrayOfBlock.length / 256;
                this.setupIslandLayer(i, j);
                for(int k = 255; k >= 0; k--)
                {
                    int i6 = (i4 * 16 + i3) * i5 + k;
                    if(this.spawnFlag == -1 && this.spawnHigh == 0)
                    {
                        this.spawnHigh = 69;
                        this.spawnPoint = true;
                    }
                    int var100 = this.roundNess[k];
                    int var101 = this.getSqrt(j, i, 8, 8);
                    if(k > 32 && var101 > var100)
                    {
                        par3ArrayOfBlock[i6] = Blocks.air;
                        continue;
                    }
                    else if((!this.round && k > 32) ||(k > 32 && this.skip))
                    {
                        par3ArrayOfBlock[i6] = Blocks.air;
                        continue;
                    }
                    else if(k < 32)
                    {
                        par3ArrayOfBlock[i6] = Blocks.water;
                        continue;
                    }
                    else if(k <= 32 + this.islandHigh)
                    {
                        par3ArrayOfBlock[i6] = Blocks.air;
                        continue;
                    }
                    else if(k > 32 + this.islandHigh)
                    {
                        par3ArrayOfBlock[i6] = Blocks.stone;
                    }
                    if(k > 32 + this.islandHigh + this.islandEve)
                    {
                        par3ArrayOfBlock[i6] = Blocks.air;
                    }
 
                    Block block = par3ArrayOfBlock[i6];
                    if(block == null || block.getMaterial() == Material.air)
                    {
                        i1 = -1;
                    }
                    else if(block == Blocks.stone)
                    {
                        if(i1 == -1)
                        {
                            if(i2 <= 0)
                            {
                                topBlock = null;
                                b1 = 0;
                                fillerBlock = Blocks.stone;
                            }
                            else if(k >= 59 && k <= 64)
                            //else if(k >= 31 && k <= 255)
                            {
                                topBlock = biomeGenBase.topBlock;
                                b1 = 0;
                                fillerBlock = biomeGenBase.fillerBlock;
                            }
                            if(k < 63 && (topBlock == null || topBlock.getMaterial() == Material.air))
                            //if(k < 254 && (topBlock == null || topBlock.getMaterial() == Material.air))
                            {
                                if(biomeGenBase.getFloatTemperature(par1, k, par2) < 0.125F)
                                {
                                    topBlock = Blocks.ice;
                                }
                                else
                                {
                                    topBlock = Blocks.water;
                                }
                                b1 = 0;
                            }
                            i1 = i2;
                            if(k >= 62)
                            //if(k >= 32)
                            {
                                par3ArrayOfBlock[i6] = topBlock;
                                par4ArrayOfByte[i6] = b1;
                            }
                            else if(k < 56 - i2)
                            //else if(k < 250 - i2)
                            {
                                topBlock = null;
                                fillerBlock = Blocks.stone;
                                par3ArrayOfBlock[i6] = Blocks.gravel;
                            }
                            else
                            {
                                par3ArrayOfBlock[i6] = fillerBlock;
                            }
                        }
                        else if(i1 > 0)
                        {
                            i1--;
                            par3ArrayOfBlock[i6] = fillerBlock;
                            if(i1 == 0 && fillerBlock == Blocks.sand)
                            {
                                i1 = this.rand.nextInt(4) + Math.max(0, k - 63);
                                fillerBlock = Blocks.sandstone;
                            }
                        }
                    }
                }
            }
        }
    }
 
    @Override
    public Chunk loadChunk(int par1, int par2)
    {
        return provideChunk(par1, par2);
    }
 
    public Chunk provideChunk(int par1, int par2)
    {
        this.rand.setSeed((long)par1 * 341873128712L + (long)par2 * 132897987541L);
        Block[] arrayOfBlock = new Block[65536];
        byte[] arrayOfByte  = new byte[65536];
        generateTerrain(par1, par2, arrayOfBlock);
        this.biomesForGeneration = this.worldObj.getWorldChunkManager().loadBlockGeneratorData(this.biomesForGeneration, par1 * 16, par2 * 16, 16, 16);
        replaceBlocksForBiome(par1, par2, arrayOfBlock, arrayOfByte , this.biomesForGeneration);
        this.caveGenerator.func_151539_a(this, this.worldObj, par1, par2, arrayOfBlock);
        this.ravineGenerator.func_151539_a(this, this.worldObj, par1, par2, arrayOfBlock);
        if (this.mapFeaturesEnabled)
        {
            this.mineshaftGenerator.func_151539_a(this, this.worldObj, par1, par2, arrayOfBlock);
            this.villageGenerator.func_151539_a(this, this.worldObj, par1, par2, arrayOfBlock);
            this.strongholdGenerator.func_151539_a(this, this.worldObj, par1, par2, arrayOfBlock);
            this.scatteredFeatureGenerator.func_151539_a(this, this.worldObj, par1, par2, arrayOfBlock);
        }
        Chunk chunk = new Chunk(this.worldObj, arrayOfBlock, arrayOfByte , par1, par2);
        byte[] arrayOfByte2 = chunk.getBiomeArray();
        for(int i = 0; i < arrayOfByte2.length; i++)
        {
            arrayOfByte2[i] = (byte)this.biomesForGeneration[i].biomeID;
        }
        chunk.generateSkylightMap();
        return chunk;
    }
 
    private void initializeNoiseField(int p_147423_1_, int p_147423_2_, int p_147423_3_)
    {
        double d0 = 684.412D;
        double d1 = 684.412D;
        double d2 = 512.0D;
        double d3 = 512.0D;
        this.field_147426_g = this.noiseGen6.generateNoiseOctaves(this.field_147426_g, p_147423_1_, p_147423_3_, 5, 5, 200.0D, 200.0D, 0.5D);
        this.field_147427_d = this.noiseGen3.generateNoiseOctaves(this.field_147427_d, p_147423_1_, p_147423_2_, p_147423_3_, 5, 33, 5, 8.555150000000001D, 4.277575000000001D, 8.555150000000001D);
        this.field_147428_e = this.noiseGen1.generateNoiseOctaves(this.field_147428_e, p_147423_1_, p_147423_2_, p_147423_3_, 5, 33, 5, 684.412D, 684.412D, 684.412D);
        this.field_147425_f = this.noiseGen2.generateNoiseOctaves(this.field_147425_f, p_147423_1_, p_147423_2_, p_147423_3_, 5, 33, 5, 684.412D, 684.412D, 684.412D);
        boolean flag1 = false;
        boolean flag = false;
        int l = 0;
        int i1 = 0;
        double d4 = 8.5D;
 
        for (int j1 = 0; j1 < 5; ++j1)
        {
            for (int k1 = 0; k1 < 5; ++k1)
            {
                float f = 0.0F;
                float f1 = 0.0F;
                float f2 = 0.0F;
                byte b0 = 2;
                BiomeGenBase biomegenbase = this.biomesForGeneration[j1 + 2 + (k1 + 2) * 10];
 
                for (int l1 = -b0; l1 <= b0; ++l1)
                {
                    for (int i2 = -b0; i2 <= b0; ++i2)
                    {
                        BiomeGenBase biomegenbase1 = this.biomesForGeneration[j1 + l1 + 2 + (k1 + i2 + 2) * 10];
                        float f3 = biomegenbase1.rootHeight;
                        float f4 = biomegenbase1.heightVariation;
 
                        if (this.worldType == WorldType.AMPLIFIED && f3 > 0.0F)
                        {
                            f3 = 1.0F + f3 * 2.0F;
                            f4 = 1.0F + f4 * 4.0F;
                        }
 
                        float f5 = this.parabolicField[l1 + 2 + (i2 + 2) * 5] / (f3 + 2.0F);
 
                        if (biomegenbase1.rootHeight > biomegenbase.rootHeight)
                        {
                            f5 /= 2.0F;
                        }
 
                        f += f4 * f5;
                        f1 += f3 * f5;
                        f2 += f5;
                    }
                }
 
                f /= f2;
                f1 /= f2;
                f = f * 0.9F + 0.1F;
                f1 = (f1 * 4.0F - 1.0F) / 8.0F;
                double d12 = this.field_147426_g[i1] / 8000.0D;
 
                if (d12 < 0.0D)
                {
                    d12 = -d12 * 0.3D;
                }
 
                d12 = d12 * 3.0D - 2.0D;
 
                if (d12 < 0.0D)
                {
                    d12 /= 2.0D;
 
                    if (d12 < -1.0D)
                    {
                        d12 = -1.0D;
                    }
 
                    d12 /= 1.4D;
                    d12 /= 2.0D;
                }
                else
                {
                    if (d12 > 1.0D)
                    {
                        d12 = 1.0D;
                    }
 
                    d12 /= 8.0D;
                }
 
                ++i1;
                double d13 = (double)f1;
                double d14 = (double)f;
                d13 += d12 * 0.2D;
                d13 = d13 * 8.5D / 8.0D;
                double d5 = 8.5D + d13 * 4.0D;
 
                for (int j2 = 0; j2 < 33; ++j2)
                {
                    double d6 = ((double)j2 - d5) * 12.0D * 128.0D / 256.0D / d14;
 
                    if (d6 < 0.0D)
                    {
                        d6 *= 4.0D;
                    }
 
                    double d7 = this.field_147428_e[l] / 512.0D;
                    double d8 = this.field_147425_f[l] / 512.0D;
                    double d9 = (this.field_147427_d[l] / 10.0D + 1.0D) / 2.0D;
                    double d10 = MathHelper.denormalizeClamp(d7, d8, d9) - d6;
 
                    if (j2 > 29)
                    {
                        double d11 = (double)((float)(j2 - 29) / 3.0F);
                        d10 = d10 * (1.0D - d11) + -10.0D * d11;
                    }
 
                    this.field_147434_q[l] = d10;
                    ++l;
                }
            }
        }
    }
 
    @Override
    public boolean chunkExists(int par1, int par2)
    {
        return true;
    }
 
    public void populate(IChunkProvider par1IChunkProvider, int par2, int par3)
    {
        BlockFalling.fallInstantly  = true;
        int i1 = par2 * 16;
        int i2 = par3 * 16;
        BiomeGenBase biomegenbase = this.worldObj.getBiomeGenForCoords(i1 + 16, i2 + 16);
        this.rand.setSeed(this.worldObj.getSeed());
        long l1 = this.rand.nextLong() / 2L * 2L + 1L;
        long l2 = this.rand.nextLong() / 2L * 2L + 1L;
        this.rand.setSeed(par2 * l1 + par3 * l2 ^ this.worldObj.getSeed());
        boolean flag = false;
 
        MinecraftForge.EVENT_BUS.post(new PopulateChunkEvent.Pre(par1IChunkProvider, this.worldObj, this.rand, par2, par3, flag));
        if (this.mapFeaturesEnabled)
        {
            this.mineshaftGenerator.generateStructuresInChunk(this.worldObj, this.rand, par2, par3);
            flag = this.villageGenerator.generateStructuresInChunk(this.worldObj, this.rand, par2, par3);
            this.strongholdGenerator.generateStructuresInChunk(this.worldObj, this.rand, par2, par3);
            this.scatteredFeatureGenerator.generateStructuresInChunk(this.worldObj, this.rand, par2, par3);
        }
 
        int var100, var101, var102, var103;
        boolean doGenerate = TerrainGen.populate(par1IChunkProvider, this.worldObj, this.rand, par2, par3, flag, PopulateChunkEvent.Populate.EventType.LAKE);
        if (biomegenbase != BiomeGenBase.desert && biomegenbase != BiomeGenBase.desertHills && !flag && this.rand.nextInt(4) == 0 && doGenerate)
        {
            var100 = i1 + this.rand.nextInt(16) + 8;
            var101 = this.rand.nextInt(256);
            var102 = i2 + this.rand.nextInt(16) + 8;
            new WorldGenLakes(Blocks.water).generate(this.worldObj, this.rand, var100, var101, var102);
        }
        
        doGenerate = TerrainGen.populate(par1IChunkProvider, this.worldObj, this.rand, par2, par3, flag, PopulateChunkEvent.Populate.EventType.LAVA);
        if (!flag && this.rand.nextInt(8) == 0 && doGenerate)
        {
            var100 = i1 + this.rand.nextInt(16) + 8;
            var101 = this.rand.nextInt(this.rand.nextInt(248) + 8);
            var102 = i2 + this.rand.nextInt(16) + 8;
            if (var101 < 63 || this.rand.nextInt(10) == 0)
            {
                new WorldGenLakes(Blocks.lava).generate(this.worldObj, this.rand, var100, var101, var102);
            }
        }
        
        doGenerate = TerrainGen.populate(par1IChunkProvider, this.worldObj, this.rand, par2, par3, flag, PopulateChunkEvent.Populate.EventType.DUNGEON);
        for(int i = 0; doGenerate && i < 8; i++)
        {
            var100 = i1 + this.rand.nextInt(16) + 8;
            var101 = this.rand.nextInt(256);
            var102 = i2 + this.rand.nextInt(16) + 8;
            new WorldGenDungeons().generate(this.worldObj, this.rand, var100, var101, var102);
        }
        
        biomegenbase.decorate(this.worldObj, this.rand, i1, i2);
        doGenerate = TerrainGen.populate(par1IChunkProvider, this.worldObj, this.rand, par2, par3, flag, PopulateChunkEvent.Populate.EventType.ANIMALS);
        if(doGenerate)
            SpawnerAnimals.performWorldGenSpawning(this.worldObj, biomegenbase, i1 + 8, i2 + 8, 16, 16, this.rand);
        i1 += 8;
        i2 += 8;
 
        doGenerate = TerrainGen.populate(par1IChunkProvider, this.worldObj, this.rand, par2, par3, flag, PopulateChunkEvent.Populate.EventType.ICE);
        for(int i = 0; doGenerate && i < 16; i++)
        {
            for(int k = 0; k < 16; k++)
            {
                var100 = this.worldObj.getPrecipitationHeight(i1 + i, i2 + k);
                if(this.worldObj.isBlockFreezable(i + i1, i2 - 1, k + i2))
                {
                    this.worldObj.setBlock(i + i1, i2 - 1, k + i2, Blocks.ice, 0, 2);
                }
                if(this.worldObj.func_147478_e(i + i1, i2, k + i2, true))
                {
                    this.worldObj.setBlock(i + i1, i2, k + i2, Blocks.snow_layer, 0, 2);
                }
            }
        }
        MinecraftForge.EVENT_BUS.post(new PopulateChunkEvent.Post(par1IChunkProvider, this.worldObj, this.rand, par2, par3, flag));
 
        BlockFalling.fallInstantly  = false;
    }
 
    @Override
    public boolean saveChunks(boolean par1, IProgressUpdate par2IProgressUpdate)
    {
        return true;
    }
 
    @Override
    public void saveExtraData()
    {
        //
    }
 
    public boolean unloadQueuedChunks()
    {
        return false;
    }
 
    @Override
    public boolean canSave()
    {
        return true;
    }
 
    @Override
    public String makeString()
    {
        return "RandomLevelSource";
    }
 
    @Override
    public List getPossibleCreatures(EnumCreatureType arg0, int arg1, int arg2, int arg3)
    {
        BiomeGenBase biomegenbase = this.worldObj.getBiomeGenForCoords(arg1, arg3);
        return (arg0 == EnumCreatureType.monster) && (this.scatteredFeatureGenerator.func_143030_a(arg1, arg2, arg3)) ? this.scatteredFeatureGenerator.getScatteredFeatureSpawnList() : biomegenbase.getSpawnableList(arg0);
    }
 
    @Override
    public ChunkPosition func_147416_a(World arg0, String arg1, int arg2, int arg3, int arg4)
    {
        return "Stronghold".equals(arg1) && this.strongholdGenerator != null ? this.strongholdGenerator.func_151545_a(arg0, arg2, arg3, arg4) : null;
    }
 
    @Override
    public int getLoadedChunkCount()
    {
        return 0;
    }
 
    @Override
    public void recreateStructures(int par1, int par2)
    {
        if (this.mapFeaturesEnabled)
        {
            this.mineshaftGenerator.func_151539_a(this, this.worldObj, par1, par2, (Block[])null);
            this.villageGenerator.func_151539_a(this, this.worldObj, par1, par2, (Block[])null);
            this.strongholdGenerator.func_151539_a(this, this.worldObj, par1, par2, (Block[])null);
            this.scatteredFeatureGenerator.func_151539_a(this, this.worldObj, par1, par2, (Block[])null);
        }
    }
 
}